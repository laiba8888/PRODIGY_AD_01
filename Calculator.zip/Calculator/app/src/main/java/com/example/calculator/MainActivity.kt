package com.example.calculator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.calculator.ui.theme.CalculatorTheme
import net.objecthunter.exp4j.ExpressionBuilder

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CalculatorTheme {
                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFFBB86FC))
                ) { innerPadding ->
                    CalculatorApp(modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }
}

@Composable
fun CalculatorApp(modifier: Modifier = Modifier) {
    var displayText by remember { mutableStateOf("0") }
    var expressionText by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Heading section with dark pink background and default font
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFE91E63)) // Dark Pink Background
                .padding(bottom = 16.dp, top = 8.dp, start = 8.dp),
            horizontalArrangement = Arrangement.Start,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Calculator",
                fontSize = 32.sp,
                color = Color.White,
                style = TextStyle(
                    fontFamily = FontFamily.SansSerif, // Default system font
                    fontWeight = FontWeight.Bold
                )
            )
        }

        // Display box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color.White, shape = RoundedCornerShape(8.dp))
                .padding(16.dp),
            contentAlignment = Alignment.CenterEnd
        ) {
            Text(
                text = displayText,
                fontSize = 72.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black
            )
        }

        // Buttons
        val buttons = listOf(
            listOf("7", "8", "9", "/"),
            listOf("4", "5", "6", "*"),
            listOf("1", "2", "3", "-"),
            listOf("0", "C", "=", "+")
        )

        buttons.forEachIndexed { rowIndex, row ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                row.forEach { buttonText ->
                    val buttonColor = when (buttonText) {
                        in "0".."9" -> Color(0xFFE57373) // Pink
                        "C" -> Color(0xFFFF9800) // Dark Orange
                        "=" -> Color(0xFF1E88E5) // Dark Blue
                        in listOf("+", "-", "*", "/", "=") -> Color(0xFF9575CD) // Purple
                        else -> Color(0xFF64B5F6) // Blue
                    }
                    CalculatorButton(
                        text = buttonText,
                        color = buttonColor,
                        modifier = Modifier
                            .weight(1f)
                            .aspectRatio(1f)
                            .border(2.dp, Color.Black) // Black border
                    ) {
                        when (buttonText) {
                            "=" -> {
                                displayText = calculateResult(expressionText)
                                expressionText = displayText
                            }
                            "C" -> {
                                displayText = "0"
                                expressionText = ""
                            }
                            else -> {
                                // Handle number and operator input
                                if (displayText == "0" && buttonText !in listOf(".", "+", "-", "*", "/")) {
                                    displayText = buttonText
                                } else {
                                    displayText += buttonText
                                }
                                expressionText += buttonText
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CalculatorButton(text: String, color: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier
            .padding(4.dp)
            .fillMaxSize(),
        colors = ButtonDefaults.buttonColors(
            containerColor = color,
            contentColor = Color.White
        ),
        shape = RoundedCornerShape(8.dp)
    ) {
        Text(text = text, fontSize = 40.sp, fontWeight = FontWeight.Bold)
    }
}

fun calculateResult(expression: String): String {
    return try {
        val expr = ExpressionBuilder(expression).build()
        val result = expr.evaluate()
        result.toString()
    } catch (e: Exception) {
        "Error"
    }
}

@Preview(showBackground = true)
@Composable
fun CalculatorAppPreview() {
    CalculatorTheme {
        CalculatorApp()
    }
}
